import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ScrollView,
  SafeAreaView,
  Alert,
  Image,
  ActivityIndicator,
  StyleSheet,
} from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import { Ionicons } from '@expo/vector-icons';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { storage } from '../servicio/firebase-config';
import estilosComunes, { COLORES } from '../assets/estilos';

export default function EvidenciasCorrectivo({ route, navigation }) {
  const { datosInforme, procesosRealizados, observaciones } = route.params;

  const [evidencias, setEvidencias] = useState([]);
  const [descripcionActual, setDescripcionActual] = useState('');
  const [imagenSeleccionada, setImagenSeleccionada] = useState(null);
  const [cargando, setCargando] = useState(false);

  const tomarFoto = async () => {
    try {
      const { status } = await ImagePicker.requestCameraPermissionsAsync();
      
      if (status !== 'granted') {
        Alert.alert('Permiso denegado', 'Se necesita acceso a la cámara para tomar fotos');
        return;
      }

      const resultado = await ImagePicker.launchCameraAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        aspect: [4, 3],
        quality: 0.7,
      });

      if (!resultado.canceled && resultado.assets && resultado.assets.length > 0) {
        setImagenSeleccionada(resultado.assets[0].uri);
      }
    } catch (error) {
      console.error('Error al tomar foto:', error);
      Alert.alert('Error', 'No se pudo tomar la foto');
    }
  };

  const seleccionarDeGaleria = async () => {
    try {
      const resultado = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        aspect: [4, 3],
        quality: 0.7,
      });

      if (!resultado.canceled && resultado.assets && resultado.assets.length > 0) {
        setImagenSeleccionada(resultado.assets[0].uri);
      }
    } catch (error) {
      console.error('Error al seleccionar imagen:', error);
      Alert.alert('Error', 'No se pudo seleccionar la imagen');
    }
  };

  const agregarEvidencia = () => {
    if (!imagenSeleccionada) {
      Alert.alert('Error', 'Primero selecciona o toma una foto');
      return;
    }

    if (!descripcionActual.trim()) {
      Alert.alert('Error', 'Escribe una descripción para la imagen');
      return;
    }

    const evidencia = {
      uri: imagenSeleccionada,
      descripcion: descripcionActual,
      id: Date.now().toString(),
      urlFirebase: null,
    };

    setEvidencias(prev => [...prev, evidencia]);
    setDescripcionActual('');
    setImagenSeleccionada(null);
    
    Alert.alert('Éxito', 'Evidencia agregada correctamente');
  };

  const eliminarEvidencia = (id) => {
    Alert.alert(
      'Eliminar evidencia',
      '¿Estás seguro de eliminar esta evidencia?',
      [
        { text: 'Cancelar', style: 'cancel' },
        { 
          text: 'Eliminar', 
          style: 'destructive',
          onPress: () => setEvidencias(prev => prev.filter(e => e.id !== id))
        },
      ]
    );
  };

  const subirImagenesAFirebase = async () => {
    setCargando(true);
    const evidenciasConUrls = [];

    try {
      for (const evidencia of evidencias) {
        const response = await fetch(evidencia.uri);
        const blob = await response.blob();
        
        const nombreArchivo = `correctivos/${datosInforme.codigoSGS}_${Date.now()}_${evidencia.id}.jpg`;
        const storageRef = ref(storage, nombreArchivo);
        
        await uploadBytes(storageRef, blob);
        const url = await getDownloadURL(storageRef);
        
        evidenciasConUrls.push({
          ...evidencia,
          urlFirebase: url,
        });
      }

      return evidenciasConUrls;
    } catch (error) {
      console.error('Error al subir imágenes:', error);
      throw error;
    } finally {
      setCargando(false);
    }
  };

  const finalizarYGuardar = async () => {
    try {
      setCargando(true);
      
      let evidenciasFinales = evidencias;
      
      if (evidencias.length > 0) {
        evidenciasFinales = await subirImagenesAFirebase();
      }

      navigation.navigate('ResumenCorrectivo', {
        datosInforme,
        procesosRealizados,
        observaciones,
        evidencias: evidenciasFinales,
      });
    } catch (error) {
      Alert.alert('Error', 'No se pudieron subir las imágenes. Intenta de nuevo.');
    } finally {
      setCargando(false);
    }
  };

  if (cargando) {
    return (
      <SafeAreaView style={{ flex: 1, backgroundColor: COLORES.fondo }}>
        <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
          <ActivityIndicator size="large" color={COLORES.primario} />
          <Text style={{ marginTop: 20, fontSize: 16, color: COLORES.texto }}>
            Subiendo imágenes...
          </Text>
          <Text style={{ marginTop: 10, fontSize: 12, color: '#666' }}>
            {evidencias.length} {evidencias.length === 1 ? 'imagen' : 'imágenes'}
          </Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: COLORES.fondo }}>
      <View style={estilosComunes.encabezado}>
        <TouchableOpacity 
          onPress={() => navigation.goBack()}
          style={{ padding: 8 }}
        >
          <Text style={{ fontSize: 24, color: COLORES.texto }}>←</Text>
        </TouchableOpacity>
        <Text style={[estilosComunes.titulo, { margin: 0 }]}>
          Evidencias
        </Text>
        <View style={{ width: 40 }} />
      </View>

      <ScrollView 
        style={{ flex: 1 }} 
        contentContainerStyle={{ padding: 24 }}
      >
        <Text style={{ fontSize: 16, color: '#666', marginBottom: 20 }}>
          Agrega fotografías como evidencia del mantenimiento realizado
        </Text>

        {/* Formulario para agregar evidencia */}
        <View style={styles.contenedorFormulario}>
          <Text style={estilosComunes.etiqueta}>Capturar/Seleccionar Imagen</Text>
          
          <View style={styles.botonesImagen}>
            <TouchableOpacity
              style={styles.botonIcono}
              onPress={tomarFoto}
            >
              <Ionicons name="camera" size={32} color={COLORES.primario} />
              <Text style={styles.textoBotonIcono}>Tomar Foto</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.botonIcono}
              onPress={seleccionarDeGaleria}
            >
              <Ionicons name="image" size={32} color={COLORES.primario} />
              <Text style={styles.textoBotonIcono}>Galería</Text>
            </TouchableOpacity>
          </View>

          {/* Vista previa de imagen seleccionada */}
          {imagenSeleccionada && (
            <View style={styles.vistaPrevia}>
              <Image
                source={{ uri: imagenSeleccionada }}
                style={styles.imagenPrevia}
                resizeMode="cover"
              />
              <TouchableOpacity
                style={styles.botonEliminarPrevia}
                onPress={() => setImagenSeleccionada(null)}
              >
                <Ionicons name="close-circle" size={28} color="#e74c3c" />
              </TouchableOpacity>
            </View>
          )}

          <Text style={estilosComunes.etiqueta}>Descripción de la evidencia</Text>
          <TextInput
            style={[
              estilosComunes.entrada,
              { 
                height: 100, 
                textAlignVertical: 'top',
                paddingTop: 10,
              }
            ]}
            value={descripcionActual}
            onChangeText={setDescripcionActual}
            placeholder="Describe qué se muestra en la imagen..."
            multiline
            numberOfLines={4}
          />

          <TouchableOpacity
            style={[
              estilosComunes.boton, 
              { 
                backgroundColor: imagenSeleccionada ? '#3498db' : '#ccc',
              }
            ]}
            onPress={agregarEvidencia}
            disabled={!imagenSeleccionada}
          >
            <Ionicons 
              name="add-circle" 
              size={20} 
              color="#fff" 
              style={{ marginRight: 8 }} 
            />
            <Text style={estilosComunes.textoBoton}>
              Agregar Evidencia
            </Text>
          </TouchableOpacity>
        </View>

        {/* Lista de evidencias agregadas */}
        <Text style={{ fontSize: 16, fontWeight: 'bold', marginTop: 20, marginBottom: 12 }}>
          Evidencias Agregadas ({evidencias.length})
        </Text>

        {evidencias.length === 0 ? (
          <View style={styles.mensajeVacio}>
            <Ionicons name="images-outline" size={50} color="#ccc" />
            <Text style={{ color: '#666', textAlign: 'center', marginTop: 10 }}>
              No hay evidencias agregadas aún
            </Text>
          </View>
        ) : (
          evidencias.map((evidencia, index) => (
            <View 
              key={evidencia.id}
              style={styles.tarjetaEvidencia}
            >
              <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8 }}>
                <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                  <Ionicons name="image" size={16} color={COLORES.primario} />
                  <Text style={{ fontWeight: 'bold', fontSize: 12, color: '#999', marginLeft: 6 }}>
                    Evidencia {index + 1}
                  </Text>
                </View>
                <TouchableOpacity
                  onPress={() => eliminarEvidencia(evidencia.id)}
                  style={{ padding: 4 }}
                >
                  <Ionicons name="trash" size={20} color="#e74c3c" />
                </TouchableOpacity>
              </View>
              
              <Image
                source={{ uri: evidencia.uri }}
                style={styles.imagenEvidencia}
                resizeMode="cover"
              />
              
              <Text style={{ fontSize: 13, color: '#333', lineHeight: 18, marginTop: 8 }}>
                {evidencia.descripcion}
              </Text>
            </View>
          ))
        )}

        <TouchableOpacity
          style={[estilosComunes.boton, { backgroundColor: '#27ae60', marginTop: 20 }]}
          onPress={finalizarYGuardar}
        >
          <Ionicons 
            name="checkmark-circle" 
            size={20} 
            color="#fff" 
            style={{ marginRight: 8 }} 
          />
          <Text style={estilosComunes.textoBoton}>
            {evidencias.length > 0 ? 'Finalizar y Ver Resumen' : 'Continuar sin Evidencias'}
          </Text>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  contenedorFormulario: {
    backgroundColor: '#f8f9fa',
    padding: 16,
    borderRadius: 8,
    marginBottom: 20,
  },
  botonesImagen: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginBottom: 16,
  },
  botonIcono: {
    alignItems: 'center',
    padding: 16,
    backgroundColor: '#fff',
    borderRadius: 8,
    borderWidth: 2,
    borderColor: COLORES.primario,
    width: '45%',
  },
  textoBotonIcono: {
    marginTop: 8,
    fontSize: 12,
    color: COLORES.texto,
    fontWeight: '600',
  },
  vistaPrevia: {
    position: 'relative',
    marginBottom: 16,
    borderRadius: 8,
    overflow: 'hidden',
  },
  imagenPrevia: {
    width: '100%',
    height: 250,
    borderRadius: 8,
  },
  botonEliminarPrevia: {
    position: 'absolute',
    top: 8,
    right: 8,
    backgroundColor: '#fff',
    borderRadius: 14,
  },
  mensajeVacio: {
    padding: 40,
    alignItems: 'center',
    backgroundColor: '#f8f9fa',
    borderRadius: 8,
    borderWidth: 2,
    borderColor: '#e0e0e0',
    borderStyle: 'dashed',
  },
  tarjetaEvidencia: {
    backgroundColor: '#fff',
    padding: 12,
    borderRadius: 8,
    marginBottom: 12,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
  },
  imagenEvidencia: {
    width: '100%',
    height: 200,
    borderRadius: 8,
  },
});